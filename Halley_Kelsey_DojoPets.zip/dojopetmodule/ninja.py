from dojopetmodule import Pet #DOESNT WORK NEED HELP WITH MODULE. 
class Ninja:
    def __init__(self, first_name, pet): #how does declaring pet variable here link to Pet class???
        self.first_name= first_name
        self.pet= pet #how does this link to pet class???
    def walk(self):
        self.pet.play()
        self.pet.display_health_and_energy()
    def feed(self):
        self.pet.eat()
        self.pet.display_health_and_energy()
    def bathe(self):
        self.pet.noise()
        self.pet.display_health_and_energy()



turtle=Pet("turtle", "jumps", 100, 100) #pass in arguments here???
cat=Pet("cat","bites",100,100)
kirby=Ninja("kirby",turtle)
Andy=Ninja("Andy", cat)
#kirby.walk() #pass in arguments here???
#kirby.bathe()
#Andy.feed()
kirby.feed()
kirby.walk()
kirby.walk()
kirby.walk() #cant chain together get error???