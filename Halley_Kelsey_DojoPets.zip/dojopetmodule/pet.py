class Pet:

    def __init__(self, name, tricks, health, energy):
        self.name= name
        self.tricks= tricks
        self.health= health
        self.energy= energy

    def sleep(self):
        self.energy+=(self.energy*1.5)
        return self

    def eat(self):
        if self.health>75:
            self.health+=(self.health*1.25)
            self.energy+=(self.energy *1.25)
            print("I'm not hungry right now!")
        elif self.health<25:
            self.health+=(self.health*1.25)
            self.energy+=(self.energy *1.25)
            print("You should probably feed me twice...")
        else:
            self.health+=(self.health*1.25)
            self.energy+=(self.energy *1.25)
        return self

    def play(self):
        if self.energy<20:
            print(f"I cant walk right now {self.name} needs to sleep and eat first!")
        else:
            self.energy-=(self.energy*0.75)
            print("walking!")
        return self

    def display_health_and_energy(self):
        print(f"{self.name}'s energy level is {self.energy}")
        print((f"{self.name}'s health level is {self.health}"))

    def noise(self):
        self.energy-=(self.energy*0.9)
        print(f"my name is {self.name}")
        return self

